<template>
  <div id="footer">
    © 2019 Tech Share
  </div>
</template>

<script>
  export default {
    name: "Footer"
  }
</script>

<style scoped>
  #footer{
    margin-top: 10px;
    width: 100%;
    height: 24px;
    line-height: 24px;
    font-size: 14px;
    text-align: center;
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
    bottom: 0;
  }
</style>
