export const siteTitle = 'techshare'
export const siteTitleInFull = 'technology share for you'
